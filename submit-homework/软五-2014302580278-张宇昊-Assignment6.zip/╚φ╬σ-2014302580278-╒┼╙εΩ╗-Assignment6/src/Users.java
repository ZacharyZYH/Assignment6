import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Users {
	Database2014302580278 db;
	ResultSet rs = null;
	ArrayList<User> myUsers;
	int petsInCart[] = new int[12];
	public Users(){ 
		myUsers = new ArrayList<User>();
		db = new Database2014302580278();
	}
	public class User{
		public String id;
		public String pwd;
		public int[] cart = new int[12];
		public User(String a, String b){
			id = a;
			pwd = b;
			myUsers.add(this);
			db.execUpdateSQL("insert into 2014302580278_users values('"
								+ id +"',"
								+ " '"+pwd 
								+"', 0'" 
								+"', 0'"
								+"', 0'"
								+"', 0'"
								+"', 0'"
								+"', 0'"
								+"', 0'" 
								+"', 0'"
								+"', 0'"
								+"', 0'"
								+"', 0'"
								+"', 0'"
								+"')");
		}
	}
	
	//登陆
	public String search(String id, String pw) throws SQLException{
		ResultSet rs1 = null;
		try {
			rs1 = db.stmt.executeQuery("select * from 2014302580278_users");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String a = "";
		String b = "";
		String c = "noMatch";
			
		while(rs1.next()){
			a = rs1.getString("id");
			b = rs1.getString("pw");
			if(a != null && b != null){
				if( a.equals(id) && b.equals(pw)){
					c = a;
					rs = rs1;
					for(int i = 0; i < 12; i++){
						petsInCart[i] = rs.getInt(i+3);
					}
					break;				
				}
			}
		}
		
		return c;
	}
	
	//注册
	public void createId(String id, String pw){
		db.execUpdateSQL("insert into 2014302580278_users values('"+id+"',"+ " '"
				+pw +"', '"
				+ 0 +"', ' "
				+ 0 +"', ' "
				+ 0 +"', ' "
				+ 0 +"', ' "
				+ 0 +"', ' "
				+ 0 +"', ' "
				+ 0 +"', ' "
				+ 0 +"', ' "
				+ 0 +"', ' "
				+ 0 +"', ' "
				+ 0 +"', ' "
				+ 0 +"')");
	}
		
	//添加购物车
	public void addToCart(String userId, int a1, int a2, int a3, int a4, int a5, int a6,
							int a7, int a8, int a9, int a10, int a11, int a12) throws SQLException{
		petsInCart[0] += a1;
		petsInCart[1] += a2;
		petsInCart[2] += a3;
		petsInCart[3] += a4;
		petsInCart[4] += a5;
		petsInCart[5] += a6;
		petsInCart[6] += a7;
		petsInCart[7] += a8;
		petsInCart[8] += a9;
		petsInCart[9] += a10;
		petsInCart[10] += a11;
		petsInCart[11] += a12;
		db.execUpdateSQL("UPDATE `assignment3`.`2014302580278_users` SET `dog`='" + petsInCart[0] +
																"', `cat`='" + petsInCart[1] +
																"', `turtle`='" + petsInCart[2] +
																"', `parrot`='" + petsInCart[3] +
																"', `hamster`='" + petsInCart[4] +
																"', `squirrel`='" + petsInCart[5] +
																"', `rabbit`='" + petsInCart[6] +
																"', `snake`='" + petsInCart[7] +
																"', `lizard`='" + petsInCart[8] +
																"', `fish`='" + petsInCart[9] +
																"', `myna`='" + petsInCart[10] +
																"', `canary`='" + petsInCart[11] +
							"' WHERE `id`='" + userId + "';");
		System.out.println(petsInCart[0]);
	}
	
	//清空购物车
	public void clearCart(String userId){
		db.execUpdateSQL("UPDATE `assignment3`.`2014302580278_users` SET `dog`='0', `cat`='0', "
				+ "`turtle`='0', `parrot`='0', `hamster`='0', `squirrel`='0', `rabbit`='0', "
				+ "`snake`='0', `lizard`='0', `fish`='0', `myna`='0', `canary`='0' WHERE `id`='"
				+ userId + "';");
		for(int i = 0; i < 12; i++){
			petsInCart[i] = 0;
		}
	}
	
	//读取购物车
	public String readCart(String userId) throws SQLException{
		String output = "your shopping cart:\n";
		String[] pets = new String[12];
		pets[0] = "dog";
		pets[1] = "cat";
		pets[2] = "turtle";
		pets[3] = "parrot";
		pets[4] = "hamster";
		pets[5] = "squirrel";
		pets[6] = "rabbit";
		pets[7] = "snake";
		pets[8] = "lizard";
		pets[9] = "fish";
		pets[10] = "myna";
		pets[11] = "canary";
		int tem = 0;
		for(int i = 0; i < 12; i++){
			if(petsInCart[i] != 0){
				tem ++;
				if(tem % 2 != 0)
					output = output + pets[i] + ":" + petsInCart[i] + ";             ";
				else
					output = output + pets[i] + ":" + petsInCart[i] + ";\n";
			}
		}
		return output;
	}
	
}

