import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class GUI {
	final Users users = new Users();
	private String id = "";
	private static JFrame mainJF;
	
	//登录界面元素
	private static JTextArea userId;		
	private static JTextArea password;
	private static JButton create;
	private static JButton login;
	JTextArea word1 = new JTextArea("id:");
	JTextArea word2 = new JTextArea("password:");
	
	//店铺界面元素
	private static JLabel table;
	private static ImageIcon tab = new ImageIcon("./lib/table.png");
	private static JTextArea cart;
	private static JButton logout;
	private static JButton purchase;
	private static JButton add1;
	private static JButton add2;
	private static JButton add3;
	private static JButton add4;
	private static JButton add5;
	private static JButton add6;
	private static JButton add7;
	private static JButton add8;
	private static JButton add9;
	private static JButton add10;
	private static JButton add11;
	private static JButton add12;
	
	public static void main(String[] args) {
		GUI gui = new GUI() ;
	}
	
	public GUI(){
		mainJF = new JFrame("pets store");
		mainJF.setBounds(300, 100, 700, 600);
		mainJF.setLayout(null);
		mainJF.setResizable(false);
		mainJF.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		mainJF.setVisible(true);

		init1();
		JOptionPane.showMessageDialog(mainJF.getContentPane(),
				"如果已有账号，输入账号密码后点击Login\n如果没有账号，请输入自己想要的账号密码后点击Create an account", "提示", JOptionPane.INFORMATION_MESSAGE);
		
		
		

	}

	//初始化登录界面
	public void init1(){
		mainJF.add(word1);
		word1.setVisible(true);
		word1.setBounds(175, 200, 15, 20);
		word1.setBackground(mainJF.getBackground());
		word1.setEditable(false);
		
		mainJF.add(word2);
		word2.setVisible(true);
		word2.setBounds(130, 250, 60, 20);
		word2.setBackground(mainJF.getBackground());
		word2.setEditable(false);
		
		userId = new JTextArea();
		mainJF.add(userId);
		userId.setVisible(true);
		userId.setBounds(200, 200, 300, 20);
		userId.requestFocusInWindow();
		userId.setText("");
		
		password = new JTextArea();
		mainJF.add(password);
		password.setVisible(true);
		password.setBounds(200, 250, 300, 20);
		password.setText("");
		login = new JButton("Login");
		mainJF.add(login);
		login.setVisible(true);
		login.setBounds(300, 300, 100, 40);
		login.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
            	try {
            		id = users.search(userId.getText(), password.getText());
					if(id == "noMatch"){
						JOptionPane.showMessageDialog(mainJF.getContentPane(),
								"账号或密码错误", "提示", JOptionPane.INFORMATION_MESSAGE);
						userId.setText("");
						password.setText("");
					}
					else{
						JOptionPane.showMessageDialog(mainJF.getContentPane(),
								"登录成功", "提示", JOptionPane.INFORMATION_MESSAGE);
						init2();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        });
		
		create = new JButton("Create an account");
		mainJF.add(create);
		create.setVisible(true);
		create.setBounds(250, 370, 200, 40);
		create.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
            	users.createId(userId.getText(), password.getText());
            	id = userId.getText();
            	try {
					init2();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        });
	}
	
	//隐藏登录界面元素
	public void setInvisible1(){
		login.setVisible(false);
		create.setVisible(false);
		userId.setVisible(false);
		password.setVisible(false);
		word1.setVisible(false);
		word2.setVisible(false);
	}
	
	//购买界面
	public void init2() throws SQLException{
		setInvisible1();
		logout = new JButton("logout");
		mainJF.add(logout);
		logout.setVisible(true);
		logout.setBounds(580, 20, 100, 40);
		logout.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
        		setInvisible2();
            	init1();
            }
        });
		
		purchase = new JButton("buy them!");
		mainJF.add(purchase);
		purchase.setVisible(true);
		purchase.setBounds(470, 20, 100, 40);
		purchase.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
        		users.clearCart(id);
        		cart.setText("your shopping cart:\n");
        		JOptionPane.showMessageDialog(mainJF.getContentPane(),
						"购买成功！", "提示", JOptionPane.INFORMATION_MESSAGE);
            }
        });
		
		cart = new JTextArea();
		mainJF.add(cart);
		cart.setVisible(true);
		cart.setVisible(true);
		cart.setEditable(false);
		cart.setBounds(50, 20, 400, 150);
		cart.setText(users.readCart(id));
		
		
		table = new JLabel();
		mainJF.add(table ,1);
		table.setVisible(true);
		table.setBounds(50, 200, 586, 273);
		table.setIcon(tab);
		table.setVisible(true);
		
		add1 = new JButton("");
		mainJF.add(add1, 0);
		add1.setVisible(true);
		add1.setBackground(Color.red);
		add1.setBounds(600, 235, 16, 16);	
		add1.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
        		
				try {
					users.addToCart(id, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
					cart.setText(users.readCart(id));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
            }
        });
		
		add2 = new JButton("");
		mainJF.add(add2, 0);
		add2.setVisible(true);
		add2.setBackground(Color.red);
		add2.setBounds(600, 255, 16, 16);	
		add2.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
        		
				try {
					users.addToCart(id, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
					cart.setText(users.readCart(id));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
            }
        });
		
		add3 = new JButton("");
		mainJF.add(add3, 0);
		add3.setVisible(true);
		add3.setBackground(Color.red);
		add3.setBounds(600, 275, 16, 16);
		add3.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
        		
				try {
					users.addToCart(id, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
					cart.setText(users.readCart(id));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
            }
        });
		
		add4 = new JButton("");
		mainJF.add(add4, 0);
		add4.setVisible(true);
		add4.setBackground(Color.red);
		add4.setBounds(600, 295, 16, 16);	
		add4.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
        		
				try {
					users.addToCart(id, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0);
					cart.setText(users.readCart(id));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
            }
        });	
		
		add5 = new JButton("");
		mainJF.add(add5, 0);
		add5.setVisible(true);
		add5.setBackground(Color.red);
		add5.setBounds(600, 315, 16, 16);	
		add5.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
        		
				try {
					users.addToCart(id, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
					cart.setText(users.readCart(id));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
            }
        });
		
		add6 = new JButton("");
		mainJF.add(add6, 0);
		add6.setVisible(true);
		add6.setBackground(Color.red);
		add6.setBounds(600, 335, 16, 16);	
		add6.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
        		
				try {
					users.addToCart(id, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
					cart.setText(users.readCart(id));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
            }
        });
		
		add7 = new JButton("");
		mainJF.add(add7, 0);
		add7.setVisible(true);
		add7.setBackground(Color.red);
		add7.setBounds(600, 355, 16, 16);
		add7.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
        		
				try {
					users.addToCart(id, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0);
					cart.setText(users.readCart(id));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
            }
        });
		
		add8 = new JButton("");
		mainJF.add(add8, 0);
		add8.setVisible(true);
		add8.setBackground(Color.red);
		add8.setBounds(600, 375, 16, 16);	
		add8.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
        		
				try {
					users.addToCart(id, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0);
					cart.setText(users.readCart(id));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
            }
        });
		
		add9 = new JButton("");
		mainJF.add(add9, 0);
		add9.setVisible(true);
		add9.setBackground(Color.red);
		add9.setBounds(600, 395, 16, 16);	
		add9.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
        		
				try {
					users.addToCart(id, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0);
					cart.setText(users.readCart(id));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
            }
        });
		
		add10 = new JButton("");
		mainJF.add(add10, 0);
		add10.setVisible(true);
		add10.setBackground(Color.red);
		add10.setBounds(600, 415, 16, 16);	
		add10.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
        		
				try {
					users.addToCart(id, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0);
					cart.setText(users.readCart(id));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
            }
        });
		
		add11 = new JButton("");
		mainJF.add(add11, 0);
		add11.setVisible(true);
		add11.setBackground(Color.red);
		add11.setBounds(600, 435, 16, 16);
		add11.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
        		
				try {
					users.addToCart(id, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0);
					cart.setText(users.readCart(id));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
            }
        });
		
		add12 = new JButton("");
		mainJF.add(add12, 0);
		add12.setVisible(true);
		add12.setBackground(Color.red);
		add12.setBounds(600, 455, 16, 16);	
		add12.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
        		
				try {
					users.addToCart(id, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1);
					cart.setText(users.readCart(id));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
            }
        });
		
		
	}
	
	//隐藏店铺界面元素
	public void setInvisible2(){
	table.setVisible(false);
	cart.setVisible(false);
	logout.setVisible(false);
	purchase.setVisible(false);
	add1.setVisible(false);
	add2.setVisible(false);
	add3.setVisible(false);
	add4.setVisible(false);
	add5.setVisible(false);
	add6.setVisible(false);
	add7.setVisible(false);
	add8.setVisible(false);
	add9.setVisible(false);
	add10.setVisible(false);
	add11.setVisible(false);
	add12.setVisible(false);
	}
}