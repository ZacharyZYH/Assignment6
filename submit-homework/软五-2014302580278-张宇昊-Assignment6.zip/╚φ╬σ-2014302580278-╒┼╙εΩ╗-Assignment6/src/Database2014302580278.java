import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;

public class Database2014302580278 {
	private String url;
	public Connection conn = null;
	public Statement stmt;
	
	
	public Database2014302580278() {
		this.url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456&useUnicode=true&characterEncoding=UTF8";	 
		Connect();
	}

	
	/**
	 * @return
	 * Open Connection
	 */
	public void Connect(){
		
			try {
				Class.forName("com.mysql.jdbc.Driver");
				try {
					conn = DriverManager.getConnection(url);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					stmt = conn.createStatement();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("加载MySQL驱动程序成功");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
	}
	public void closeConn(){
		try {
			conn.close();
		} catch (SQLException e) {
			System.out.println("关闭连接时出错");
		}
	}
	
	//写入数据库
	public synchronized int execUpdateSQL(String str){
		int result;
		try {
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			result = stmt.executeUpdate(str);
			return result;
		} catch (SQLException e) {
			System.out.println("语法错误或未连接数据库或数据库编码错误");
			return -1;
		}
	}
}
